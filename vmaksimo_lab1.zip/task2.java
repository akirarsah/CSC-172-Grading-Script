import java.util.Arrays;
import java.util.Scanner;

public class task2 {
	public static boolean isRotation(String a, String b){
		if(a.length() != b.length()){
			return false;
		}

		for(int offset = 0; offset < a.length(); offset++){
			boolean identical = true;

			for(int i = 0; i < a.length(); i++){
				if(a.charAt((i + offset) % a.length()) != b.charAt(i)){
					identical = false;
				}
			}

			if(identical){
				return true;
			}
		}

		return false;
	}

	public static void main(String[] args){
		String a, b;

		Scanner scanner = new Scanner(System.in);
		a = scanner.nextLine();
		b = scanner.nextLine();

		System.out.println(isRotation(a, b));
	}
}