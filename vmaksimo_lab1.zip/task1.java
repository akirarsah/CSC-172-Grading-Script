import java.util.Arrays;
import java.util.Scanner;

public class task1 {
	public static boolean isAnagram(String a, String b){
		char tA[] = a.toCharArray();
		char tB[] = b.toCharArray();

		Arrays.sort(tA);
		Arrays.sort(tB);

		boolean identical = true;

		if(tA.length != tB.length){
			return false;
		}

		for(int i = 0; i < tA.length; i++){
			if(tA[i] != tB[i]){
				return false;
			}
		}

		return true;
	}

	public static void main(String[] args){
		String a, b;

		Scanner scanner = new Scanner(System.in);
		a = scanner.nextLine();
		b = scanner.nextLine();

		System.out.println(isAnagram(a, b));
	}
}