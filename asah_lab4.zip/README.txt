CSC 172 Lab 4
Student: Vladimir Maksimovski
Email: vmaksimo@u.rochester.edu

--------------Synopsis-------------
The lab performs all operations as indicated. Any possible errors indicated on the handout, as well as any out-of-bounds reference either leads to an error or no action from the program. 
-------------Documentation---------
DNAList.java  : Parses the given file
Sequence.java : Supports the operations expected of each sequence in the sequence array
LList.java    : A doubly linked list supporting generics that is application-independent. Supported functionality is indicated at the start of the file.
Node.java     : A node in a linked list supporting generics.
-------------Compilation-----------
javac *.java && java DNAList $ARG1$ $ARG2$
-------------Legalese--------------
I did not have a lab partner. I did all work individually, without any use of external material not mentioned in the course.
